# A Tkinter drag and drop widget

This code implements a Tkinter widget that can be dragged and dropped.

The widget for Python can be customized by creating a subclass and adding to it children widgets on `__init__()` declaration and binding it with the `bind_child()` function. Futhermore, its default behavior is to be placed at the point at which it was dropped, but it can be changed by overriding 

**Read the [docs](#) for more information**
